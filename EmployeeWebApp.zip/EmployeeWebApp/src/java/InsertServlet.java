// InsertServlet.java
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String name=request.getParameter("name");
        String dept=request.getParameter("department");
        int salary =Integer.parseInt(request.getParameter("salary")); 
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "Miruthula@8072");

            // Prepare the SQL INSERT statement
            PreparedStatement ps = conn.prepareStatement("INSERT INTO employees (name, department, salary) VALUES (?,?,?)");
            ps.setString(1, name);
            ps.setString(2, dept);
            ps.setInt(3, salary);
          

            // Execute the update
            int result = ps.executeUpdate();
            
            if (result > 0) {
                out.print("<h3>Record Inserted Successfully</h3>");
            }
            
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("<h3>Error: " + e.getMessage() + "</h3>");
        }

        out.print("<br><a href=\"dataVisual.jsp\">Display</a>");
        out.close();
    }
}
